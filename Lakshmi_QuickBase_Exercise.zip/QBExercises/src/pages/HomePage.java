package pages;

import org.openqa.selenium.By;

import core.BaseScript;

/**
 * Page Object class for the landing page of webdriver.io
 * @author Lakshmi
 *
 */
public class HomePage extends BaseScript {
	
	/**
	 * Method to locate the "Home" link and click on it.
	 */
    public void clickHomeLink()
    {
    	driver.findElement(By.name("Home")).click();
    }
     
    /**
	 * Method to locate the "Developer Guide" link and click on it.
	 */
    public void clickDeveloperGuideLink()
    {
    	driver.findElement(By.linkText("Developer Guide")).click();
    }
     
    /**
	 * Method to locate the "API" link and click on it.
	 */
    public void clickAPILink()
    {
    	driver.findElement(By.linkText("API")).click();
    }
     
    /**
	 * Method to locate the "Contribute" link and click on it.
	 */
    public void clickContributeLink()
    {
    	driver.findElement(By.linkText("Contribute")).click();
    }
   
    /**
	 * Method to locate the "search" TextField and enter a value in it.
	 */
    public void search(String searchString)
    {
    	driver.findElement(By.id("docsearch")).sendKeys(searchString);
    }

	
}
