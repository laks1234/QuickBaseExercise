package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import core.BaseScript;

public class APIPage extends BaseScript{
	
	/**
	 * Method to locate the "Action" submenu link and click on it.
	 */
	public void clickActionMenu()
    {
    	driver.findElement(By.linkText("Action")).click();
    }
	
	/**
	 * Method to locate all the members below the "Action" link
	 * @return --- A List of all the web element ids
	 */
	public List<WebElement>  getActionElements()
    {
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='commands action active']"));
    
		return list;
    }
		
	/**
	 * Method to locate "Search" Text Field enter the value that is passed as the argument
	 * @param searchString --- word to search on the UI
	 */
	public void search(String searchString)
	{
	  	driver.findElement(By.name("search")).sendKeys(searchString);    
	}

	/**
	 * Method to locate all the submenus appearing on the left navigation side
	 * @return --- A List of all the web element ids
	 */
	public List<WebElement> submenusList() {
		
		List<WebElement> list = driver.findElements(By.xpath("//a[@class='icon-folder-close-alt']"));
		
		return list;
	}
}

