package testcases;

import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import core.BaseScript;
import pages.APIPage;
import pages.HomePage;

/**
 * TestCases given by QuickBase to test on webdriver.io
 * @author Lakshmi
 *
 */
public class SearchFunctionality extends BaseScript {
	
	final static Logger logger = Logger.getLogger(SearchFunctionality.class);
	
	/**
	 * Setup method from Parent Class to load properties values, instantiate the web
	 * driver and launches the given url in the specified browser
	 */
	@Test(priority = 1)
	public void launchUrlTest() {

		try {
			setUp();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * First test case to search for "click" on the API page and display results.
	 * This method execution depends on the success of the above test case.
	 */
	@Test(priority = 2, dependsOnMethods = "launchUrlTest")
	public void findAllClicksTest() {

		// UI Navigation
		HomePage app = new HomePage();
		app.clickAPILink();

		APIPage api = new APIPage();
		api.search("click");
		api.clickActionMenu();

		logger.info("********************************************************************");
		logger.info("The list of actions with the search word --- click --- are as below.");
		logger.info("********************************************************************");
		
		// Get the list of result elements and compare with given 5 values
		List<WebElement> actualList = api.getActionElements();
		for (int i = 0; i < actualList.size(); i++) {
			logger.info(actualList.get(i).getText());
		}

		logger.info("********************************************************************");
	}

	/**
	 * Second test case to search for "time" on the same search field on the API
	 * page and display results. This method execution depends on the success of the
	 * first "launchUrlTest" test case.
	 */
	@Test(priority = 3, dependsOnMethods = "launchUrlTest")
	public void findTheSectionNameTest() {

		// UI Navigation
		HomePage app = new HomePage();
		app.clickAPILink();

		APIPage api = new APIPage();
		api.search("time");
		// api.submenusList();

		logger.info("********************************************************************");
		logger.info("The Sections that have the searched word --- time --- are as below.");
		logger.info("********************************************************************");
	
		// Get the list of result elements
		List<WebElement> sectionList = api.submenusList();
		for (int i = 0; i < sectionList.size(); i++) {
			logger.info(sectionList.get(i).getText());
		}
		logger.info("********************************************************************");
	}
}
