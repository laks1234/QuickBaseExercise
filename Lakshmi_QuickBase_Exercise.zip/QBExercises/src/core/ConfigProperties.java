package core;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Class to read the values of the properties required for the test cases to run
 * @author Lakshmi
 *
 */
public class ConfigProperties {
		
		protected InputStream input = null;
		protected Properties prop = null;
		String path = "resource/config.properties";
		
		/**
		 * Constructor that loads the property file
		 */
		public ConfigProperties() {
			try {
				input = ConfigProperties.class.getClassLoader().getResourceAsStream(path);
				prop = new Properties();
				prop.load(input);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
			
		/**
		 * Method that reads the value of the url 
		 * @return
		 */
		public String getUrl() {
			if(prop.getProperty("url") == null)
				return "";
			return prop.getProperty("url");
		}
		
		/**
		 * Method that reads the value of the browser 
		 * @return
		 */
		public String getBrowser() {
			if(prop.getProperty("browser") == null)
				return "";
			return prop.getProperty("browser");
		}
		
	}
