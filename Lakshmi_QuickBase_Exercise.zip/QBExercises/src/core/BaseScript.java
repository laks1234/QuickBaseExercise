package core;

import java.io.IOException;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterSuite;

/**
 * Class that does the initial set up for test execution
 * @author Lakshmi
 *
 */
public class BaseScript {
	
public static WebDriver driver;
	
/**
 * Method that does the following :
 * 1. Reads the browser and url values from the config.properties file
 * 2. Initiates the appropriate browser based on the above value
 * 3. Launches the url
 * @throws IOException
 */
	public static void setUp() throws IOException{
		
		String chromeExePath = "resource/chromedriver.exe";
		String internetExplorerExePath = "resource/IEDriverServer.exe";
		PropertyConfigurator.configure("log4j.properties");
			ConfigProperties file = new ConfigProperties();
			if("firefox".equalsIgnoreCase(file.getBrowser())){
				driver = new FirefoxDriver();
			}else if("chrome".equalsIgnoreCase(file.getBrowser())){
				System.setProperty("webdriver.chrome.driver", WebDriver.class.getClassLoader().getResource(chromeExePath).getPath());
					ChromeOptions cOptions = new ChromeOptions();
				    cOptions.addArguments("test-type");
				    cOptions.addArguments("start-maximized");
				    cOptions.addArguments("disable-infobars");  
				    cOptions.addArguments("--disable-popup-blocking");
				    cOptions.addArguments("--disable-default-apps"); 
				    driver = new ChromeDriver(cOptions);
			}else if("explorer".equalsIgnoreCase(file.getBrowser())){
				System.setProperty("webdriver.ie.driver", WebDriver.class.getClassLoader().getResource(internetExplorerExePath).getPath());
				driver = new InternetExplorerDriver();
			}else{
				driver = new HtmlUnitDriver();
			}
			driver.get(file.getUrl());
		}
	
	/**
	 * Method to close the browser after all test cases execution are completed and 
	 * to nullify the driver object
	 */
	@AfterSuite(alwaysRun=true)
	public void tearDown() {
		try {
			driver.close();
			driver.quit();
			if(driver != null)
				driver = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
